from setuptools import setup, find_packages
setup(
    name = 'tensorized_fwd_bwd',
    packages = find_packages(),
)
